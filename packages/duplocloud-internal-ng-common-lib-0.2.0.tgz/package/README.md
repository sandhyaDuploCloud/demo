# @duplocloud-internal/ng-common-lib

Shared **Angular** UI library for DuploCloud apps — components, services, models, pipes, directives, and utilities. Published to **GitHub Packages**.

> Requires Angular **22.1.x**. Other major versions are not supported.

---

## 1. Configure the registry

This package lives on GitHub Packages under the `@duplocloud-internal` scope.

**Project `.npmrc`** (committed — registry mapping only, no token):
```
@duplocloud-internal:registry=https://npm.pkg.github.com
```

**One-time auth, per machine** — put your token in your *global* `~/.npmrc` (not the project). After this, `npm install` just works in any project, with no per-install step:
```bash
# if you use the GitHub CLI:
npm config set //npm.pkg.github.com/:_authToken=$(gh auth token) --location=user

# or paste a Personal Access Token (classic) with read:packages scope:
npm config set //npm.pkg.github.com/:_authToken=ghp_xxxxxxxx --location=user
```

> You must be a member of the `duplocloud-internal` org with package read access. CI needs no setup — `GITHUB_TOKEN` is injected automatically.

## 2. Install

```bash
npm install @duplocloud-internal/ng-common-lib
```

Strict npm resolution — **no `--legacy-peer-deps`**. Install the **peer dependencies** too (most already exist in an Angular 22 app):

`@angular/core`, `@angular/common`, `@angular/forms`, `@angular/router`, `@angular/platform-browser`, `@angular/cdk`, `@angular/material` (all `^22.1.0`), `rxjs@^7.8.0`, `@ng-bootstrap/ng-bootstrap@^21.0.0`, `@ng-select/ng-select@^23.5.1`, `@ngbracket/ngx-layout@^22.0.1`, `@ngx-translate/core@^18.0.0`, `@swimlane/ngx-datatable@^25.0.0`, `ngx-echarts@^22.0.0`, `ngx-markdown@^22.0.0`, `ngx-monaco-editor-v2@^22.0.4`, `ngx-toastr@^20.0.5`, `angularx-flatpickr@^8.1.0`, `echarts@^6.1.0`, `marked@^18.0.7`, `flatpickr@^4.6.9`, `@popperjs/core@^2.11.8`, `monaco-editor@^0.55.1`.

> **ngx-toastr caveat**: there is currently no Angular-22 release of `ngx-toastr` on npm. Mirror the portal's own `package.json` `overrides` block so it resolves against your app's `@angular/core`/`@angular/common`:
> ```json
> "overrides": {
>   "ngx-toastr": {
>     "@angular/common": "$@angular/common",
>     "@angular/core": "$@angular/core"
>   }
> }
> ```

`ng-block-ui` is **not** on this list — it ships bundled inside the package. See [§6](#6-loading-overlays-ng-block-ui).

---

## 3. Set up in your `AppModule`

```typescript
import {
  CommonLibModule,            // runtime config (forRoot)
  CommonLibComponentsModule,  // datatables, modals, viewers, cards, BlockUI…
  CoreCommonModule,           // feather-icon / ripple directives + core pipes
  SharedFormsModule,          // form fields + validators
  BlockUIModule,              // loading overlay (bundled ng-block-ui fork)
} from '@duplocloud-internal/ng-common-lib';
import { environment } from '../environments/environment';

@NgModule({
  imports: [
    CommonLibModule.forRoot({
      apiUrl: environment.apiUrl,         // base URL for DuploApiInterceptor
      mixpanelToken: environment.mixpanelToken,  // optional; empty = analytics off
    }),
    BlockUIModule.forRoot(),
    CommonLibComponentsModule,
    CoreCommonModule,
    SharedFormsModule,
  ],
})
export class AppModule {}
```

`CommonLibModule.forRoot(...)` is called **once** at the app root. All fields are optional — omitted values fall back to defaults (`apiUrl: '/'`, analytics off).

---

## 4. Use it

```typescript
import {
  ConfirmationModalService,
  FilterTableUtils,
  DuploHttpClient,
  EnumUtils,
  YamlUtils,
} from '@duplocloud-internal/ng-common-lib';
```

```html
<searchable-datatable [rows]="rows" [columns]="columns"></searchable-datatable>
<view-with-sidecards> … </view-with-sidecards>
<status-with-style [status]="status"></status-with-style>
```

**Standalone components** (e.g. `SpinnerComponent`, `YamlSnippetEditorComponent`) — import directly into a component's `imports`, no module needed:

```typescript
import { SpinnerComponent } from '@duplocloud-internal/ng-common-lib';

@Component({ standalone: true, imports: [SpinnerComponent], /* … */ })
export class MyComponent {}
```

---

## 5. Host responsibilities (contracts the library can't own)

- **`window.appBrandTitle`** — some components/models read this global. Set it before common-lib renders (e.g. in `index.html` or app bootstrap).
- **App initialization** — the library does **not** ship an `APP_INITIALIZER`. If you need to preload `SystemFeatures` before bootstrap, provide your own factory.

---

## 6. Loading overlays (ng-block-ui)

`ng-block-ui` is a DuploCloud-maintained fork, built as its own Angular library and shipped **inside** the `ng-common-lib` tarball (`bundleDependencies` → a nested `node_modules/ng-block-ui`). You never install it separately — every symbol is re-exported through `@duplocloud-internal/ng-common-lib`.

**Setup** — import `BlockUIModule` once at the app root (already shown in [§3](#3-set-up-in-your-appmodule)):
```typescript
import { BlockUIModule } from '@duplocloud-internal/ng-common-lib';

@NgModule({ imports: [BlockUIModule.forRoot()] })
export class AppModule {}
```

**Template directive** — wrap the region to block with `*blockUI`, naming the instance:
```html
<div *blockUI="'myBlock'">
  … content that gets covered by the spinner …
</div>
```

**Component decorator** — bind a named instance and drive it from code:
```typescript
import { BlockUI, NgBlockUI } from '@duplocloud-internal/ng-common-lib';

@Component({ /* ... */ })
export class MyComponent {
  @BlockUI('myBlock') blockUI: NgBlockUI;

  load() {
    this.blockUI.start('Loading...');
    // ...
    this.blockUI.stop();
  }
}
```
`NgBlockUI` also exposes `.update(message)` (change the message on an active block) and `.reset()` (force-clear regardless of nested start-call count).

**Global blocking** — omit the name to drive the app-wide instance:
```typescript
@BlockUI() blockUI: NgBlockUI;
```

**Service alternative** — inject `BlockUIService` to start/stop one or more named blocks without a decorator, e.g. from a guard or interceptor:
```typescript
import { BlockUIService } from '@duplocloud-internal/ng-common-lib';

constructor(private blockUIService: BlockUIService) {}

this.blockUIService.start('myBlock', 'Loading...');
this.blockUIService.stop('myBlock');
this.blockUIService.update('myBlock', 'Almost done...');
this.blockUIService.reset('myBlock');           // or an array of names
this.blockUIService.resetGlobal();              // resets every instance
```

**In-repo (portal / ai-studio) developers**: the fork's source lives at `common-lib/ng-block-ui/`, not inside `common-lib/` proper. It is built to `dist/ng-block-ui` once per install by a guarded `postinstall` script (`scripts/postinstall-build-block-ui.js`), which no-ops on dependency-only layers (e.g. the Docker builder stage) where `angular.json` isn't present yet. If you edit the fork's source, rebuild it manually with `npm run build:block-ui` before your changes show up. It's shared as a **native-federation singleton** (`ng-block-ui` → `portal/dist/ng-block-ui`), so the portal host and the AI Studio remote share one BlockUI world — a block started from one is visible/controllable from the other.

---

## What's inside

| Area | Highlights |
|---|---|
| **Components** | `SearchableDataTableComponent`, `ServersideDataTableComponent`, `TokenPaginatedDataTableComponent`, `ConfirmationModalComponent` (+service), `ViewJson/ViewYaml`, `ViewWithSidecardsComponent`, `ScrollableNavTabComponent`, `StatusWithStyleComponent`, `MiniCardComponent`, `CodeBlockWithCopyComponent`, xterm blocks |
| **Forms** (`SharedFormsModule`) | `GenericFormFieldComponent`, `PasswordFieldComponent`, key-value fields, validation directives (`validation-state`, `validation-errors`, INI/XML/YAML), custom validators (email, URL, IP, CIDR) |
| **Services** | `DuploHttpClient` / `DuploCiHttpClient` (SSE via `loadEventSource`), `CoreConfigService`, `CoreMenuService`, `DuploToastrService`, `ClipboardService`, `SubDestroyService`, `MixpanelService` |
| **Models** | `UserSession`, `SystemFeatures`, `TenantFeatures`, `Infrastructure`, `AdminTenant`, `CloudPlatform`/`K8sPlatform`/`UserRole` enums, `KeyValuePair` |
| **Pipes** (`CoreCommonModule`) | `PrettyJson`, `PrettyYaml`, `TimeAgo`, `Initials`, `Filter`, `OrderBy`, `Safe` |
| **Directives** (`CoreCommonModule`) | `FeatherIconDirective`, `RippleEffectDirective` |
| **Utils** | `FilterTableUtils`, `EnumUtils`, `YamlUtils`, `JSONUtils`, `StringUtils`, `DateUtils`, `extractErrorMessage`, `SharedAlertsService` |
| **BlockUI** (bundled `ng-block-ui` fork — see [§6](#6-loading-overlays-ng-block-ui)) | `BlockUIModule`, `BlockUIService`, `@BlockUI` decorator, `NgBlockUI`, `[blockUI]`/`*blockUI` directive |

All public symbols are exported from the package root (single barrel):

```typescript
import { /* anything public */ } from '@duplocloud-internal/ng-common-lib';
```

---

## Publishing (maintainers)

Releases are tag-triggered: bump `version` in `common-lib/package.json`, then tag and push `ng-common-lib-v<version>` (must match). The **Publish ng-common-lib** workflow builds and publishes to GitHub Packages. Local dry run: `npm run pack:common-lib` (builds `ng-block-ui`, builds the lib, bundles the fork in, and produces a local tarball via `npm pack`). Full details, including the manual-publish fallback and pre-publish checklist: see `common-lib/PUBLISHING.md`.

---

## Compatibility

| | |
|---|---|
| Angular | 22.1.x (peer) |
| Node (build) | ≥ 22.12.0 |
| Module format | FESM2022 + typings (Ivy partial) |
